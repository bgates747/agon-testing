### Malloc Demo

Check the address of memory allocated with malloc to make sure it is correctly in the heap
