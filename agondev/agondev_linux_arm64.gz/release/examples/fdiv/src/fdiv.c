/*
 * Title:			floating point divide example
 * Author:			Paul Cawte
 * Created:			08/06/2023
 * Last Updated:	 
 *
 * Modinfo:
 */
 
#include <stdio.h>

int main(void)
{
    float f;
    f = 50.0/9.0;
    printf( "%f\n\r", f);
}