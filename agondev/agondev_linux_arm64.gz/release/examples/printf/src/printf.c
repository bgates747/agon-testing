/*
 * Title:			printf example using standard "Hello, World!" example from K&R
 * Author:			Paul Cawte
 * Created:			08/06/2023
 * Last Updated:	08/06/2023
 *
 * Modinfo:
 */
 
#include <stdio.h>

int main(void)
{
	printf("Hello World!\n\r");

	return 0;
}