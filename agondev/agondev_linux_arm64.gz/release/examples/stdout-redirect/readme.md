### Stdout redirection example

Print "Hello, world!" first to the console and then redirects the output to a file and prints to the file, still using stdout.
