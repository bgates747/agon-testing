### Basic float demo

Using K&R f-to-c while loop example

Relies on printf, including floating point formatting and handling of variable number of parameters
