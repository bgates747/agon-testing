### Hello World Demo

Displays the text `Hello, World!` on the calculator.
