### C time function demo

Demonstrates use of:

- `clock()` - which counts in systems ticks (centi-seconds)

- `time()`, `difftime()` and `ctime()` - which use the RTC (year, month, day, hour, minute, second)

This is done by timing a trigonometric calculation loop
