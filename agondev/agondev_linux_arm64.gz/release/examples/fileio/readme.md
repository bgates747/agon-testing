### Test fileio & stdio

Tests the following functions:

- puts

- putchar

- puts

- gets_s

- fopen

- fclose

- fputs & fputc

- fgets & fgetc

- fseek

- fwrite

To do: add case for fread
