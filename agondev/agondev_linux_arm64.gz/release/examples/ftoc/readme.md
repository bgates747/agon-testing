### While loop demo

Using K&R Fahrenheit-Celsius example 

Uses printf, integer formatting and variable number of parameters
