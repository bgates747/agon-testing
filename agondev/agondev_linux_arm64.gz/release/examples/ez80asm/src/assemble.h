#ifndef ASSEMBLE_H
#define ASSEMBLE_H

#include "config.h"
#include "defines.h"

void assemble(const char *filename);
void processContent(const char *filename);

#endif // ASSEMBLE_H