#include <stdio.h>
#include "globals.h"

