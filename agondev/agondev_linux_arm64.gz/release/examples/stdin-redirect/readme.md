### Stdin redirection example

Reads from file "number.txt" which should be in the same directory as stdin.bin

Should contain for example:

```
10
20
30
40
50
60
```

With lines CR/LF terminated
