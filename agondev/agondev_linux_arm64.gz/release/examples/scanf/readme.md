### Scanf & sscanf Demo

Designed to test all of the various input formats
